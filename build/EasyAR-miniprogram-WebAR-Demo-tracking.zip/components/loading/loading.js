Component({
    properties: {
        text: {type: String, value: null},
    },
    data: {},
    lifetimes: {
        detached() {
            console.info('=-====');
        }
    },
    methods: {},
});
