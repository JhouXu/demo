import CrsClient from '../libs/crs-client';
import { atob } from '../libs/atob';

Component({
    behaviors: [require('./share-behavior').default],
    properties: {
        runingCrs: {
            type: Boolean,
            value: false,
        },
        config: Object,
        tracking: {
            type: Boolean,
            value: false,
        }
    },
    observers: {
        'runingCrs, tracking': function (value1, value2) {
            if (this.crsClient) {
                this.crsClient.runningCrs = value1;
            }
            if (!value2) {
                this.stopTracking();
            }
        },
    },
    data: {
        loaded: false,
        arReady: false,
        markerImg: '',
    },
    crsClient: undefined,
    lifetimes: {
        attached() {
            this.crsClient = new CrsClient(this.properties.config);
        }
    },
    methods: {
        handleReady({ detail }) {
            this.scene = detail.value;
            this.shadowRoot = this.scene.getElementById('shadow-root');
            this.xrFrameSystem = wx.getXrFrameSystem();
        },
        handleTick() {
            if (this.properties.runingCrs) {
                this.crsClient?.search(this.scene.ar.getARRawData(), (result) => {
                    this.crsClient.runningCrs = false;
                    this.triggerEvent('searchSuccess', result, {});

                    // 设置marker
                    this.loadTrackingImage(result.trackingImage).then(filePath => {
                        this.setData({ markerImg: filePath });
                    }).catch(err => {
                        wx.showModal({
                            title: JSON.stringify(err),
                            showCancel: false,
                        });
                    });

                    // 从meta信息中检测是模型，还是视频
                    const setting = JSON.parse(atob(result.meta));
                    console.info(setting);

                    if (setting.modelUrl) {
                        this.loadModel(result.targetId, setting);
                    } else if (setting.videoUrl) {
                        this.loadVideo(result.uuid, setting);
                    }
                });
            }
        },
        handleARReady: function ({ detail }) {
            this.setData({
                arReady: true
            });
        },
        stopTracking() {
            this.setData({
                markerImg: '',
            });
            if (this.scene) {
                const el = this.scene.getElementById('player');
                this.shadowRoot.removeChild(el);
            }
        },
        loadTrackingImage(img) {
            return new Promise((resolve, reject) => {
                const filePath = `${wx.env.USER_DATA_PATH}/marker-ar.jpeg`;
                wx.getFileSystemManager().writeFile({
                    filePath,
                    data: img,
                    encoding: 'base64',
                    success: (r) => resolve(filePath),
                    fail: (err) => reject(err),
                });
            });
        },
        loadModel: async function (targetId, setting) {
            wx.showToast({
                icon: 'none',
                title: '模型加载中...',
                duration: 2000,
            });

            let m = this.scene.assets.getAsset('gltf', targetId);
            if (!m) {
                const asset = await this.scene.assets.loadAsset({ type: 'gltf', assetId: targetId, src: setting.modelUrl });
                if (!asset) {
                    console.warn(`加载模型错误: ${setting.modelUrl}`);
                    return;
                }
                m = asset.value;
            }

            const el = this.scene.createElement(this.xrFrameSystem.XRGLTF);
            el.setId("player");
            const c = el.getComponent(this.xrFrameSystem.GLTF);
            c.setData({ model: m });
            this.shadowRoot.addChild(el);
            const animator = el.getComponent('animator');
            animator.play(setting.action || 'gltfAnimation#0');

            const t = el.getComponent(this.xrFrameSystem.Transform);
            // setting.scale = 0.4;
            t.scale.setValue(setting.scale, setting.scale, setting.scale);

            wx.showToast({
                icon: 'none',
                title: '请将相机对着识别图',
            });

        },
        loadVideo: async function (targetId, setting) {
            wx.showToast({
                icon: 'none',
                title: '视频加载中...',
                duration: 2000,
            });

            let asset = this.scene.assets.getAsset('video-texture', targetId);
            if (!asset) {
                const v = await this.scene.assets.loadAsset({
                    type: 'video-texture', assetId: targetId, src: setting.videoUrl,
                    options: { autoPlay: true, abortAudio: false }
                });
                asset = v.value;
            }
          
            const { width, height } = asset;
            const el = this.scene.createElement(this.xrFrameSystem.XRMesh, { geometry: 'plane', uniforms: `u_baseColorMap:video-${targetId}` });
            el.setId("player");
            this.shadowRoot.addChild(el);

            let w = 1;
            let h = 1;
            if (width > height) {
                h = height / width;
            } else if (width < height) {
                w = width / height;
            }

            const t = el.getComponent(this.xrFrameSystem.Transform);
            t.scale.setValue(w, 1, h);

            wx.showToast({
                icon: 'none',
                title: '请将相机对着识别图',
            });
        },
    }
})