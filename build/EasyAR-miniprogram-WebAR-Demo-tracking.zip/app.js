//app.js
App({
  onLaunch: function () {
  },
  globalData: {
  }
})