// index.ts

Page({
    data: {
        config: {
            apiKey: '这里是 api key',
            apiSecret: '这里是 api secret',
            crsAppId: '这里是 crs app id',
            clientEndUrl: '这里是云识别 Client-end (Target Recognition) URL',
            jpegQuality: 0.7, //JPEG压缩质量，建议不低于70%
            minInterval: 1000, //最短的两次CRS请求间隔(ms)
        },
    },
})
